package com.nebula.atelier;

public interface IStringSerializable
{
    String getName();
}