//------------------------------------------------------------------------------------------------
//
//   Greg's Mod Base for 1.7 Version B - Compatibility - ITickable
//
//------------------------------------------------------------------------------------------------

package com.nebula.atelier;

public interface ITickable {
    void update();
}
