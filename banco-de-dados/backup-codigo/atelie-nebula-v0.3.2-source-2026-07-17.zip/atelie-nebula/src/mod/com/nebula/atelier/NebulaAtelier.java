//------------------------------------------------------
//
//   NebulaAtelier - Main
//
//------------------------------------------------------

package com.nebula.atelier;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import java.util.Hashtable;

import net.minecraft.block.*;
import net.minecraft.creativetab.*;
import net.minecraft.entity.player.*;
import net.minecraft.init.*;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.world.*;

import net.minecraftforge.common.*;
import cpw.mods.fml.common.*;
import cpw.mods.fml.common.event.*;
import cpw.mods.fml.common.network.*;
import cpw.mods.fml.common.registry.*;

import com.nebula.atelier.BaseDataChannel.*;

@Mod(
	modid = Info.modID,
	name = Info.modName,
	version = Info.versionNumber,
	acceptableRemoteVersions = Info.versionBounds,
	acceptedMinecraftVersions = Info.acceptedMinecraftVersions)

public class NebulaAtelier extends BaseMod<NebulaAtelierClient> {

	public static NebulaAtelier mod;
	public static BaseDataChannel channel;
	
	//
	//   Blocks and Items
	//
	
	public static SawbenchBlock blockSawbench;
	public static BaseBlock blockShape;

	public static Item itemSawblade;
	public static Item itemLargePulley;
	public static Item itemChisel;
	public static Item itemHammer;
	public static CladdingItem itemCladding;

	/** Aba própria: nada do Ateliê fica perdido em Misc. */
	public static final CreativeTabs tabAtelier = new CreativeTabs("nebulaatelier") {
		@Override public Item getTabIconItem() {
			return itemSawblade != null ? itemSawblade : Items.iron_ingot;
		}
	};
	
	public NebulaAtelier() {
		super();
		creativeTab = tabAtelier;
		mod = this;
		channel = new BaseDataChannel(modID);
		//debugCreativeTabs = true;
	}
	
	@Mod.EventHandler
	public void preInit(FMLPreInitializationEvent e) {
		super.preInit(e);
	}

	@Mod.EventHandler
	public void init(FMLInitializationEvent e) {
		super.init(e);
	}
	
	@Mod.EventHandler
	public void postInit(FMLPostInitializationEvent e) {
		super.postInit(e);
	}

	@Override
	NebulaAtelierClient initClient() {
		return new NebulaAtelierClient(this);
	}

	protected void registerBlocks() {
		blockSawbench = newBlock("sawbench", SawbenchBlock.class);
		blockSawbench.setHardness(2.0F);
		blockShape = newBlock("shape", ShapeBlock.class, ShapeItem.class);
	}
	
	protected void registerTileEntities() {
		GameRegistry.registerTileEntity(SawbenchTE.class, "nebulaatelier.formbench");
		GameRegistry.registerTileEntity(ShapeTE.class, "nebulaatelier.shape");
	}
	
	protected void registerItems() {
		itemSawblade = newItem("sawblade");
		itemLargePulley = newItem("largePulley");
		itemChisel = newItem("chisel", ChiselItem.class);
		itemHammer = newItem("hammer", HammerItem.class);
		itemCladding = newItem("cladding", CladdingItem.class);
	}

	protected void registerRecipes() {
	    ItemStack orangeDye = new ItemStack(Items.dye, 1, 14);
		newRecipe(blockSawbench, 1,
			"I*I",
			"/0/",
			"/_/",
			'I', Items.iron_ingot, '*', itemSawblade, '/', Items.stick, 
			'_', Blocks.wooden_pressure_plate, '0', itemLargePulley);
		newRecipe(itemSawblade, 1,
			" I ",
			"I/I",
			" I ",
			'I', Items.iron_ingot, '/', Items.stick);
		newRecipe(itemLargePulley, 1,
			" W ",
			"W/W",
			" W ",
			'W', Blocks.planks, '/', Items.stick);
		newRecipe(itemChisel, 1,
			"I ",
			"ds",
			'I', Items.iron_ingot, 's', Items.stick, 'd', orangeDye);
		newRecipe(itemHammer, 1,
			"II ",
			"dsI",
			"ds ",
			'I', Items.iron_ingot, 's', Items.stick, 'd', orangeDye);
}
	
	//--------------- GUIs ----------------------------------------------------------

	public final static int guiSawbench = 1;
	
	@Override
	protected void registerContainers() {
		addContainer(guiSawbench, SawbenchContainer.class);
	}
	
	public void openGuiSawbench(World world, BlockPos pos, EntityPlayer player) {
		openGui(player, guiSawbench, world, pos);
	}

}
