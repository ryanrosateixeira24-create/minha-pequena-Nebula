//------------------------------------------------------
//
//   NebulaAtelier - Client Proxy
//
//------------------------------------------------------

package com.nebula.atelier;

import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import net.minecraft.tileentity.*;
import net.minecraft.world.*;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.MinecraftForgeClient;
//import cpw.mods.fml.client.registry.RenderingRegistry;

public class NebulaAtelierClient extends BaseModClient<NebulaAtelier> {

	public static ShapeRenderDispatch shapeRenderDispatch = new ShapeRenderDispatch();

	public NebulaAtelierClient(NebulaAtelier mod) {
		super(mod);
		// v0.2 não oferece a família Window. O upstream carregava todos os
		// modelos de janela no construtor do cliente; isso tornava recursos
		// invisíveis uma dependência obrigatória. A família será inicializada
		// somente quando houver janelas paramétricas próprias.
	}
	
	@Override
	void registerScreens() {
		addScreen(NebulaAtelier.guiSawbench, SawbenchGui.class);
	}

	@Override
	protected void registerBlockRenderers() {
		addBlockRenderer(base.blockShape, shapeRenderDispatch);
	}
	
	@Override
	protected void registerItemRenderers() {
		addItemRenderer(base.itemCladding, new CladdingRenderer());
	}
	
}
