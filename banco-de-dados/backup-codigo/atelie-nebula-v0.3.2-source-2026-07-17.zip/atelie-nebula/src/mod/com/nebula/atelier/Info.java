package com.nebula.atelier;

/** Preview intuitivo: galeria direta das 12 formas aprovadas. */
public final class Info {
    static final String modName = "Ateliê Nébula";
    static final String modID = "nebulaatelier";
    static final String versionNumber = "0.3.2-collision-preview";
    static final String versionBounds = "[0.3.2-collision-preview,)";
    static final String acceptedMinecraftVersions = "1.7.10";
    private Info() {}
}
