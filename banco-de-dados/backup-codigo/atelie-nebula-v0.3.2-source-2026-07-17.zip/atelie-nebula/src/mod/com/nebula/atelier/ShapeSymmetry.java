//------------------------------------------------------------------------------
//
//	 NebulaAtelier - Shape symmetries
//
//------------------------------------------------------------------------------

package com.nebula.atelier;

public enum ShapeSymmetry {

	Unilateral,
	Bilateral,
	Quadrilateral

}
