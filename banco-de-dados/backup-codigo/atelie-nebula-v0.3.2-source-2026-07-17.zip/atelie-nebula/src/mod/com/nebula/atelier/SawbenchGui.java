//------------------------------------------------------------------------------
//
//   Greg's Blocks - SawbenchGui
//
//------------------------------------------------------------------------------

package com.nebula.atelier;

import java.io.IOException;

import static org.lwjgl.opengl.GL11.*;

import net.minecraft.client.gui.inventory.*;
import net.minecraft.client.renderer.*;
import net.minecraft.entity.player.*;
import net.minecraft.tileentity.*;
//import net.minecraft.util.BlockPos;
import net.minecraft.world.*;

import com.nebula.atelier.BaseDataChannel.*;
import com.nebula.atelier.BaseModClient.*;

import static com.nebula.atelier.BaseBlockUtils.*;
import static com.nebula.atelier.BaseUtils.*;
import static com.nebula.atelier.SawbenchContainer.*;

public class SawbenchGui extends BaseGui.Screen {

	public static int pageMenuLeft = 176;
	public static int pageMenuTop = 19;
	public static int pageMenuWidth = 58;
	public static int pageMenuRowHeight = 10;
	public static float pageMenuScale = 1;
	
	public static int shapeMenuLeft = 44;
	public static int shapeMenuTop = 23;
	public static int shapeMenuMargin = 4;
	public static int shapeMenuCellSize = 24;
	public static int shapeMenuRows = 4, shapeMenuCols = 5;
	public static int shapeMenuWidth = shapeMenuCols * shapeMenuCellSize;
	public static int shapeMenuHeight = shapeMenuRows * shapeMenuCellSize;
	public static int selectedShapeTitleLeft = 40;
	public static int selectedShapeTitleTop = 128;
	public static int selectedShapeTitleRight = 168;
	public static int materialUsageLeft = 7;
	public static int materialUsageTop = 82;
	public static float shapeMenuScale = 2;
	public static float shapeMenuItemScale = 2;
	public static float shapeMenuItemUSize = 40, shapeMenuItemVSize = 45;
	public static float shapeMenuItemWidth = shapeMenuItemUSize / shapeMenuItemScale;
	public static float shapeMenuItemHeight = shapeMenuItemVSize / shapeMenuItemScale;

	static final String[] familyLabels = {"TELHADO", "ARCO", "COLUNA", "PAINEL", "GRADE"};
	static final String[] profileLabels = {"45°", "33°", "PAG.", "PONTA"};
	static final String[] topologyLabels = {"RETA", "C. EXT.", "C. INT."};

	SawbenchTE te;
	
	public static SawbenchGui create(EntityPlayer player, World world, BlockPos pos) {
		TileEntity te = getWorldTileEntity(world, pos);
		if (te instanceof SawbenchTE)
			return new SawbenchGui(player, (SawbenchTE)te);
		else
			return null;
	}
	
	public SawbenchGui(EntityPlayer player, SawbenchTE te) {
		super(new SawbenchContainer(player, te));
		this.te = te;
	}
	
	@Override
	protected void drawBackgroundLayer() {
		glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		bindTexture("gui/gui_gallery_bg.png", 512, 256);
		drawTexturedRect(0, 0, this.xSize, this.ySize, 0, 0);
		drawMoldBook();
	}

	void drawMoldBook() {
		int slot = te.selectedSlots[0];
		fontRendererObj.drawString("ATELIÊ NÉBULA", 116, 7, 0xE9B84A);
		fontRendererObj.drawString("1 MATERIAL", 12, 36, 0xE9B84A);
		fontRendererObj.drawString("2 ESCOLHA UMA FORMA", 78, 18, 0xE9B84A);
		fontRendererObj.drawString("3 PRÉVIA", 239, 36, 0xE9B84A);
		fontRendererObj.drawString("4 RESULTADO", 225, 147, 0xE9B84A);
		for (int i = 0; i < 12; i++) {
			int x = 76 + (i % 4) * 34, y = 32 + (i / 4) * 32;
			if (i == slot) drawSelectionRect(x, y, 30, 28);
			drawShapeIcon(i, x + 4, y + 3, 22, 22);
		}
		drawShapeIcon(slot, 228, 44, 78, 78);
		Shape shape = te.getSelectedShape();
		if (shape != null) fontRendererObj.drawString(shape.title, 72, 136, 0xF4EFDC);
	}

	void drawShapeIcon(int slot, int x, int y, int w, int h) {
		bindTexture("gui/shapemenu_items.png", 512, 512);
		int trow = slot / 10, tcol = slot % 10;
		drawTexturedRect(x, y, w, h, tcol * 40, trow * 45, 40, 45);
	}

	void drawSelectionRect(int x, int y, int w, int h) {
		gSave(); setColor(233/255d, 184/255d, 74/255d); drawRect(x, y, w, h); gRestore();
	}

	void drawSelectedPreview(int slot) {
		bindTexture("gui/shapemenu_items.png", 512, 512);
		int trow = slot / 10, tcol = slot % 10;
		drawTexturedRect(101, 48, 84, 88, tcol * 40, trow * 45, 40, 45);
	}
	
	void drawPageMenu() {
		glPushMatrix();
		glTranslatef(pageMenuLeft, pageMenuTop, 0);
		gSave();
		setColor(233/255d, 184/255d, 74/255d);
		drawRect(0, te.selectedPage * pageMenuRowHeight, pageMenuWidth, pageMenuRowHeight);
		gRestore();
		for (int i = 0; i < te.pages.length; i++) {
			drawString(te.pages[i].title, 1, 1);
			glTranslatef(0, pageMenuRowHeight, 0);
		}
		glPopMatrix();
	}
	
	void drawShapeMenu() {
		gSave();
		glPushMatrix();
		glDisable(GL_ALPHA_TEST);
		glEnable(GL_BLEND);
		glTranslatef(shapeMenuLeft, shapeMenuTop, 0);
		bindTexture("gui/shapemenu_bg.png", 256, 256);
		double w = shapeMenuWidth + 2 * shapeMenuMargin;
		double h = shapeMenuHeight + 2 * shapeMenuMargin;
		drawTexturedRect(-shapeMenuMargin, -shapeMenuMargin, w, h,
			0, 0, shapeMenuScale * w, shapeMenuScale * h);
		bindTexture("gui/shapemenu_items.png", 512, 512);
		int p = te.selectedPage;
		if (p >= 0 && p < te.pages.length) {
			ShapePage page = te.pages[p];
			if (page != null) {
				Shape[] shapes = page.shapes;
				for (int i = 0; i < shapes.length; i++) {
					Shape shape = shapes[i];
					int mrow = i / shapeMenuCols, mcol = i % shapeMenuCols;
					// A v0.2 não usa ID persistente como coordenada visual. O atlas é
					// ordenado pela curadoria da página e pode mudar sem quebrar NBT.
					int iconIndex = i;
					int trow = iconIndex / 10, tcol = iconIndex % 10;
					//System.out.printf("SawbenchGUI: Item %s: Rendering shape id %s from (%s, %s) at (%s, %s)\n",
					//	i, id, trow, tcol, mrow, mcol);
					drawTexturedRect(
						(mcol + 0.5) * shapeMenuCellSize - 0.5 * shapeMenuItemWidth,
						(mrow + 0.5) * shapeMenuCellSize - 0.5 * shapeMenuItemHeight,
						shapeMenuItemWidth, shapeMenuItemHeight,
						tcol * shapeMenuItemUSize, trow * shapeMenuItemVSize,
						shapeMenuItemUSize, shapeMenuItemVSize);
				}
			}
		}
		glPopMatrix();
		gRestore();
	}
				
	void drawShapeSelection() {
		int i = te.selectedSlots[te.selectedPage];
		int row = i / shapeMenuCols;
		int col = i % shapeMenuCols;
		int x = shapeMenuLeft + shapeMenuCellSize * col;
		int y = shapeMenuTop + shapeMenuCellSize * row;
		//System.out.printf("SawbenchGui.drawShapeSelection: sel=%d x=%d y=%d\n", i, x, y);
		drawTexturedRect(x, y, 24.5, 24.5, 44, 23, 49, 49);
	}
	
	void drawSelectedShapeTitle() {
		Shape shape = te.getSelectedShape();
		if (shape != null) {
			int x = selectedShapeTitleLeft;
			int w = fontRendererObj.getStringWidth(shape.title);
			if (x + w > selectedShapeTitleRight)
				x = selectedShapeTitleRight - w;
			drawString(shape.title, x, selectedShapeTitleTop);
			glPushMatrix();
			glTranslatef(materialUsageLeft, materialUsageTop, 0);
			glScalef(0.5f, 0.5f, 1.0f);
			drawString(String.format("%s makes %s", te.materialMultiple(), te.resultMultiple()), 0, 0);
			glPopMatrix();
		}
	}

	@Override
	protected void mousePressed(int x, int y, int btn) {
		if (x >= 76 && x < 212 && y >= 32 && y < 128) {
			int col = (x - 76) / 34, row = (y - 32) / 32;
			int slot = row * 4 + col;
			if (col >= 0 && col < 4 && row >= 0 && row < 3 && slot < 12) {
				sendSelectShape(0, slot);
				return;
			}
		}
		super.mousePressed(x, y, btn);
	}
	
	void clickPageMenu(int x, int y) {
		//System.out.printf("SawbenchGui.clickPageMenu: %d, %d\n", x, y);
		int i = y / pageMenuRowHeight;
		if (i >= 0 && i < te.pages.length)
			sendSelectShape(i, te.selectedSlots[i]);
	}
	
	void clickShapeMenu(int x, int y) {
		//System.out.printf("SawbenchGui.clickShapeMenu: %d, %d\n", x, y);
		int row = y / shapeMenuCellSize;
		int col = x / shapeMenuCellSize;
		if (row >= 0 && row < shapeMenuRows && col >= 0 && col < shapeMenuCols) {
			int i = row * shapeMenuCols + col;
			sendSelectShape(te.selectedPage, i);
		}
	}
	
	protected void sendSelectShape(int page, int slot) {
		ChannelOutput data = NebulaAtelier.channel.openServerContainer("SelectShape");
		data.writeInt(page);
		data.writeInt(slot);
		data.close();
	}

}
