//------------------------------------------------------------------------------
//
//	 NebulaAtelier - Shape flags
//
//------------------------------------------------------------------------------

package com.nebula.atelier;

public class ShapeFlags {

	// Shape.flags values
	public final static int placeUnderneath = 1; // Reverses the upside down placement option
	public final static int placeOffset = 2; // Offset to left or right side along X axis

}
