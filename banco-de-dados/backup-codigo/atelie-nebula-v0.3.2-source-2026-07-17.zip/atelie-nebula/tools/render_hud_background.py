#!/usr/bin/env python3
from pathlib import Path
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1]
NAVY=(18,29,55,255);PANEL=(35,53,88,255);BLUE=(54,80,128,255);GOLD=(233,184,74,255);INK=(8,14,28,255)
im=Image.new('RGBA',(512,256),(0,0,0,0));d=ImageDraw.Draw(im)
d.rounded_rectangle((0,0,319,239),radius=7,fill=NAVY,outline=GOLD,width=2)
# family bookmarks
for i in range(5):d.rounded_rectangle((8,25+i*23,65,44+i*23),radius=4,fill=PANEL,outline=BLUE)
# profile buttons
for i in range(4):d.rounded_rectangle((73+i*36,25,106+i*36,43),radius=3,fill=PANEL,outline=BLUE)
# preview
d.rounded_rectangle((72,49,213,132),radius=5,fill=INK,outline=BLUE,width=2)
# topology buttons
for i in range(7):
 x=220+(i%2)*47;y=45+(i//2)*23;d.rounded_rectangle((x,y,x+43,y+19),radius=3,fill=PANEL,outline=BLUE)
# material / result slots
for x,y in ((126,141),(274,141)):d.rectangle((x,y,x+19,y+19),fill=INK,outline=GOLD,width=2)
# player inventory
for row in range(3):
 for col in range(9):
  x=79+col*18;y=159+row*18;d.rectangle((x,y,x+17,y+17),fill=INK,outline=BLUE)
for col in range(9):
 x=79+col*18;y=217;d.rectangle((x,y,x+17,y+17),fill=INK,outline=BLUE)
out=ROOT/'src/resources/assets/nebulaatelier/textures/gui/gui_moldbook_bg.png';im.save(out);print(out)
