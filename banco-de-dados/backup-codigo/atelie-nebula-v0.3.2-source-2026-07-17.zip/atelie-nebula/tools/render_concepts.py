#!/usr/bin/env python3
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parents[1]
BG=(238,226,235); NAVY=(23,35,64); BLUE=(45,72,119); GOLD=(233,184,74); INK=(42,31,92); GREEN=(62,91,42); WHITE=(245,241,230)
try:
 FT=ImageFont.truetype('DejaVuSans-Bold.ttf',28);FH=ImageFont.truetype('DejaVuSans-Bold.ttf',20);FB=ImageFont.truetype('DejaVuSans.ttf',16)
except:FT=FH=FB=ImageFont.load_default()

profiles=[
 ('LINEAR 45°',[(0,15),(16,0)]),
 ('SUAVE 33°',[(0,11),(16,0)]),
 ('PAGODA CÔNCAVA',[(0,15),(2,11),(5,7),(9,4),(13,2),(16,0)]),
 ('PONTA ASCENDENTE',[(0,10),(2,15),(4,10),(7,6),(11,3),(16,0)]),
]

def roof_language():
 im=Image.new('RGB',(1400,900),BG);d=ImageDraw.Draw(im)
 d.text((700,20),'ATELIÊ NÉBULA — LINGUAGEM PRÓPRIA DE COBERTURAS',anchor='ma',font=FT,fill=INK)
 for i,(name,pts) in enumerate(profiles):
  x=35+(i%2)*685;y=85+(i//2)*330
  d.rounded_rectangle((x,y,x+650,y+290),radius=12,fill=WHITE,outline=NAVY,width=3)
  d.text((x+325,y+15),name,anchor='ma',font=FH,fill=INK)
  ox=x+70;oy=y+235;sx=30;sy=12
  # grade 16x16
  for g in range(17):
   d.line((ox+g*sx,oy-16*sy,ox+g*sx,oy),fill=(216,209,214),width=1)
   d.line((ox,oy-g*sy,ox+16*sx,oy-g*sy),fill=(216,209,214),width=1)
  screen=[(ox+px*sx,oy-py*sy) for px,py in pts]
  poly=screen+[(ox+16*sx,oy),(ox,oy)]
  d.polygon(poly,fill=GREEN,outline=NAVY)
  d.line(screen,fill=GOLD,width=5,joint='curve')
  d.text((x+325,y+262),'perfil em 1/16 → malha gerada, não modelo copiado',anchor='ma',font=FB,fill=(72,54,70))
 # topology ribbon
 y=760;names=['RETA','C. EXT.','C. INT.','CUMEEIRA','VALE','BEIRAL','PONTA']
 for i,n in enumerate(names):
  x=40+i*194
  d.rounded_rectangle((x,y,x+175,y+100),radius=8,fill=NAVY,outline=GOLD,width=2)
  d.text((x+87,y+72),n,anchor='ma',font=FB,fill=GOLD)
  # ícones abstratos distintos
  if i==0:d.polygon([(x+30,y+55),(x+75,y+20),(x+145,y+20),(x+100,y+55)],fill=GREEN)
  elif i==1:d.polygon([(x+35,y+55),(x+87,y+18),(x+140,y+55),(x+87,y+45)],fill=GREEN)
  elif i==2:d.line((x+30,y+22,x+87,y+55,x+145,y+22),fill=GREEN,width=12)
  elif i==3:d.polygon([(x+30,y+55),(x+87,y+17),(x+145,y+55)],fill=GREEN)
  elif i==4:d.line((x+30,y+18,x+87,y+55,x+145,y+18),fill=GREEN,width=12)
  elif i==5:d.polygon([(x+25,y+50),(x+120,y+20),(x+150,y+30),(x+55,y+60)],fill=GREEN)
  else:d.line((x+35,y+50,x+115,y+22,x+145,y+5),fill=GREEN,width=12)
 out=ROOT/'concepts/01-linguagem-coberturas.png';im.save(out);print(out)

def mold_table():
 im=Image.new('RGB',(1400,860),BG);d=ImageDraw.Draw(im)
 d.text((700,20),'MESA DE MOLDES — NÃO É UMA GRADE DE 83 ÍCONES',anchor='ma',font=FT,fill=INK)
 d.rounded_rectangle((40,75,1360,820),radius=18,fill=NAVY,outline=GOLD,width=4)
 # tabs
 tabs=['COBERTURA','ARCO','COLUNA','PAINEL','GRADE']
 for i,t in enumerate(tabs):
  x=75+i*245;sel=i==0
  d.rounded_rectangle((x,95,x+220,145),radius=8,fill=GOLD if sel else BLUE,outline=GOLD,width=2)
  d.text((x+110,109),t,anchor='ma',font=FB,fill=NAVY if sel else WHITE)
 # material
 d.text((105,180),'1  MATERIAL',font=FH,fill=GOLD)
 d.rounded_rectangle((100,220,320,440),radius=10,fill=(12,20,40),outline=BLUE,width=3)
 for yy in range(235,425,24):
  d.rectangle((118,yy,302,yy+18),fill=(61,91,42))
 d.text((210,455),'argila verde',anchor='ma',font=FB,fill=WHITE)
 # central preview
 d.text((400,180),'2  PRÉVIA PARAMÉTRICA',font=FH,fill=GOLD)
 d.rounded_rectangle((390,220,905,625),radius=12,fill=(12,20,40),outline=BLUE,width=3)
 d.polygon([(455,535),(620,355),(835,420),(675,590)],fill=GREEN,outline=GOLD)
 d.line([(455,535),(620,355),(835,420)],fill=GOLD,width=8)
 d.text((648,650),'gire a prévia • encaixe automático visível',anchor='ma',font=FB,fill=WHITE)
 # profile selection
 d.text((965,180),'3  PERFIL',font=FH,fill=GOLD)
 for i,(name,_) in enumerate(profiles):
  y=220+i*72;sel=i==2
  d.rounded_rectangle((960,y,1315,y+54),radius=7,fill=GOLD if sel else BLUE)
  d.text((977,y+16),name,font=FB,fill=NAVY if sel else WHITE)
 # topology/output
 d.text((100,535),'4  TOPOLOGIA',font=FH,fill=GOLD)
 opts=['RETA','CANTO EXT.','CANTO INT.','CUMEEIRA','VALE','BEIRAL','PONTA']
 for i,o in enumerate(opts):
  x=100+(i%4)*190;y=580+(i//4)*62
  d.rounded_rectangle((x,y,x+170,y+45),radius=6,fill=GOLD if i==1 else BLUE)
  d.text((x+85,y+12),o,anchor='ma',font=FB,fill=NAVY if i==1 else WHITE)
 d.rounded_rectangle((1000,690,1315,780),radius=10,fill=(12,20,40),outline=GOLD,width=3)
 d.text((1018,706),'RESULTADO',font=FB,fill=GOLD);d.text((1018,738),'2× Beiral Pagoda — Canto Externo',font=FB,fill=WHITE)
 out=ROOT/'concepts/02-mesa-de-moldes.png';im.save(out);print(out)

if __name__=='__main__':roof_language();mold_table()
