#!/usr/bin/env python3
"""Exporta as malhas paramétricas originais para o loader JSON .smeg do engine MIT."""
from pathlib import Path
from math import sqrt
import json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'prototype'))
from roof_geometry import PROFILES,build_mesh

OUT=ROOT/'src/resources/assets/nebulaatelier/models/shape/v02'

def norm(a,b,c):
 ux,uy,uz=(b[i]-a[i] for i in range(3));vx,vy,vz=(c[i]-a[i] for i in range(3))
 nx,ny,nz=uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx;l=sqrt(nx*nx+ny*ny+nz*nz) or 1
 return nx/l,ny/l,nz/l

def collision_boxes(profile,topology,resolution=4):
 from roof_geometry import height_function
 h=height_function(profile,topology);boxes=[]
 for z in range(resolution):
  for x in range(resolution):
   x0=x/resolution;x1=(x+1)/resolution;z0=z/resolution;z1=(z+1)/resolution
   top=max(h(x0,z0),h(x1,z0),h(x0,z1),h(x1,z1))
   if top>1e-5: boxes.append([x0-.5,-.5,z0-.5,x1-.5,top-.5,z1-.5])
 return boxes

def export(mesh,path,profile,topology):
 verts=[];tris=[]
 for face in mesh.faces:
  parts=(face,) if len(face)==3 else ((face[0],face[1],face[2]),(face[0],face[2],face[3]))
  for tri in parts:
   pts=[mesh.vertices[i] for i in tri];n=norm(*pts);idx=[]
   for x,y,z in pts:
    idx.append(len(verts));verts.append([x-.5,y-.5,z-.5,n[0],n[1],n[2],x,z])
   tris.append(idx)
 xyz=[v[:3] for v in verts]
 bounds=[min(v[0] for v in xyz),min(v[1] for v in xyz),min(v[2] for v in xyz),
         max(v[0] for v in xyz),max(v[1] for v in xyz),max(v[2] for v in xyz)]
 data={'bounds':bounds,'faces':[{'texture':1,'vertices':verts,'triangles':tris}],
       'boxes':collision_boxes(profile,topology)}
 path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(data,separators=(',',':')),encoding='utf-8')
 return len(verts),len(tris)

def main():
 totalv=totalt=0;count=0
 for profile in PROFILES:
  for topology in ('straight','outer_corner','inner_corner'):
   mesh=build_mesh(profile,topology)
   v,t=export(mesh,OUT/(mesh.name+'.smeg'),profile,topology);totalv+=v;totalt+=t;count+=1
 print('SMEG_EXPORT=OK models=%d vertices=%d triangles=%d'%(count,totalv,totalt))
if __name__=='__main__':main()
