#!/usr/bin/env python3
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
NAVY=(18,29,55);PANEL=(35,53,88);BLUE=(54,80,128);GOLD=(233,184,74);PALE=(244,239,220);GREEN=(62,91,42);INK=(8,14,28)
try:small=ImageFont.truetype('DejaVuSans.ttf',10);bold=ImageFont.truetype('DejaVuSans-Bold.ttf',11)
except:small=bold=ImageFont.load_default()

def slot(d,x,y,selected=False):
 d.rectangle((x,y,x+19,y+19),fill=INK,outline=GOLD if selected else BLUE,width=2)

def hud():
 im=Image.new('RGBA',(512,256),(0,0,0,0));d=ImageDraw.Draw(im)
 d.rounded_rectangle((0,0,319,239),radius=7,fill=NAVY,outline=GOLD,width=2)
 d.text((160,6),'LIVRO DE MOLDES',anchor='ma',font=bold,fill=GOLD)
 # family bookmarks
 families=['TELHADO','ARCO','COLUNA','PAINEL','GRADE']
 for i,name in enumerate(families):
  y=25+i*23;sel=i==0
  d.rounded_rectangle((8,y,65,y+19),radius=4,fill=GOLD if sel else BLUE)
  d.text((36,y+5),name,anchor='ma',font=small,fill=NAVY if sel else PALE)
 # profile pages top
 profiles=['45°','33°','PAG.','PONTA']
 for i,p in enumerate(profiles):
  x=73+i*36;sel=i==2
  d.rounded_rectangle((x,25,x+33,43),radius=3,fill=GOLD if sel else PANEL,outline=BLUE)
  d.text((x+16,y:=30),p,anchor='ma',font=small,fill=NAVY if sel else PALE)
 # preview
 d.rounded_rectangle((72,49,213,132),radius=5,fill=INK,outline=BLUE,width=2)
 d.polygon([(88,113),(134,68),(195,85),(151,125)],fill=GREEN,outline=GOLD)
 d.line((88,113,134,68,195,85),fill=GOLD,width=2)
 d.text((142,136),'Pagoda Côncava',anchor='ma',font=small,fill=PALE)
 # topology right
 d.text((267,28),'TOPOLOGIA',anchor='ma',font=bold,fill=GOLD)
 tops=['RETA','C. EXT.','C. INT.','CUME','VALE','BEIRAL','PONTA']
 for i,t in enumerate(tops):
  x=220+(i%2)*47;y=45+(i//2)*23;sel=i==1
  d.rounded_rectangle((x,y,x+43,y+19),radius=3,fill=GOLD if sel else PANEL,outline=BLUE)
  d.text((x+21,y+5),t,anchor='ma',font=small,fill=NAVY if sel else PALE)
 # material/output
 d.text((74,150),'MATERIAL',font=small,fill=GOLD);slot(d,126,144)
 d.text((177,150),'→',font=bold,fill=GOLD);d.text((198,150),'RESULTADO',font=small,fill=GOLD);slot(d,274,144,True)
 d.text((299,147),'×2',font=small,fill=PALE)
 # inventory 9x3 + hotbar
 for row in range(3):
  for col in range(9):slot(d,79+col*18,169+row*18)
 for col in range(9):slot(d,79+col*18,226)
 return im

def main():
 im=hud();res=ROOT/'src/resources/assets/nebulaatelier/textures/gui/gui_moldbook_v03.png';res.parent.mkdir(parents=True,exist_ok=True);im.save(res)
 # apresentação 3x com notas
 show=Image.new('RGB',(1100,850),(238,226,235));d=ImageDraw.Draw(show)
 try:ft=ImageFont.truetype('DejaVuSans-Bold.ttf',28);fb=ImageFont.truetype('DejaVuSans.ttf',18)
 except:ft=fb=ImageFont.load_default()
 d.text((550,20),'HUD REAL 320×240 — LIVRO DE MOLDES',anchor='ma',font=ft,fill=(42,31,92))
 scaled=im.crop((0,0,320,240)).resize((960,720),Image.Resampling.NEAREST);show.paste(scaled,(70,75),scaled)
 d.text((550,815),'família → perfil → topologia → prévia → material/resultado',anchor='ma',font=fb,fill=(65,45,72))
 out=ROOT/'concepts/04-hud-livro-de-moldes.png';show.save(out);print(res);print(out)
if __name__=='__main__':main()
