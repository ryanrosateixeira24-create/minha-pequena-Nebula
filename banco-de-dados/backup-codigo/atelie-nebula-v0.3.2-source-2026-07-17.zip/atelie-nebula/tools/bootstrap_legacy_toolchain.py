#!/usr/bin/env python3
"""Preenche os downloads Mojang que ForgeGradle 1.2 tenta buscar por HTTP morto."""
from pathlib import Path
import hashlib,json,os,urllib.request

gradle_home=Path(os.environ.get('GRADLE_USER_HOME',Path.home()/'.gradle'))
manifest=json.load(urllib.request.urlopen('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json'))
version=next(v for v in manifest['versions'] if v['id']=='1.7.10')
meta=json.load(urllib.request.urlopen(version['url']))
files={
 'client':gradle_home/'caches/minecraft/net/minecraft/minecraft/1.7.10/minecraft-1.7.10.jar',
 'server':gradle_home/'caches/minecraft/net/minecraft/minecraft_server/1.7.10/minecraft_server-1.7.10.jar',
}
for kind,path in files.items():
 info=meta['downloads'][kind];path.parent.mkdir(parents=True,exist_ok=True)
 valid=path.exists() and hashlib.sha1(path.read_bytes()).hexdigest()==info['sha1']
 if not valid:
  print('downloading',kind,info['url']);urllib.request.urlretrieve(info['url'],path)
 sha=hashlib.sha1(path.read_bytes()).hexdigest()
 if sha!=info['sha1']:raise SystemExit('%s SHA1 mismatch'%kind)
 print(kind,'OK',path.stat().st_size,sha)
print('Use Gradle with: -PverifiedMojangJars')
