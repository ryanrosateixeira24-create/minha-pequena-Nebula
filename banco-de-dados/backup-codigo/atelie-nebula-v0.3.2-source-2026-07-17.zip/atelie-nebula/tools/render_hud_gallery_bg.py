#!/usr/bin/env python3
from pathlib import Path
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1]
N=(18,29,55,255);P=(35,53,88,255);B=(54,80,128,255);G=(233,184,74,255);I=(8,14,28,255)
im=Image.new('RGBA',(512,256),(0,0,0,0));d=ImageDraw.Draw(im)
d.rounded_rectangle((0,0,319,239),radius=7,fill=N,outline=G,width=2)
# material, galeria, preview
d.rounded_rectangle((8,28,65,132),radius=5,fill=P,outline=B,width=2)
d.rounded_rectangle((72,28,215,132),radius=5,fill=I,outline=B,width=2)
d.rounded_rectangle((222,28,312,132),radius=5,fill=I,outline=B,width=2)
# slot material/output
for x,y in ((27,73),(278,141)):d.rectangle((x,y,x+19,y+19),fill=I,outline=G,width=2)
# galeria 4x3
for row in range(3):
 for col in range(4):
  x=76+col*34;y=32+row*32;d.rounded_rectangle((x,y,x+30,y+28),radius=3,fill=P,outline=B)
# inventário
for row in range(3):
 for col in range(9):
  x=79+col*18;y=159+row*18;d.rectangle((x,y,x+17,y+17),fill=I,outline=B)
for col in range(9):
 x=79+col*18;d.rectangle((x,217,x+17,234),fill=I,outline=B)
out=ROOT/'src/resources/assets/nebulaatelier/textures/gui/gui_gallery_bg.png';im.save(out);print(out)
