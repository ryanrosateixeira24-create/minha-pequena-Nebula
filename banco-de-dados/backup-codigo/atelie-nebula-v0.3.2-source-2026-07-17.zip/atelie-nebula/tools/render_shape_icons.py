#!/usr/bin/env python3
from pathlib import Path
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'src/resources/assets/nebulaatelier/textures/gui/shapemenu_items.png'
profiles=[[(3,34),(34,7)],[(3,29),(34,10)],[(3,34),(8,22),(17,15),(27,10),(34,7)],[(3,24),(8,34),(14,21),(24,13),(34,9)]]
img=Image.new('RGBA',(512,512),(0,0,0,0))
for pr,curve in enumerate(profiles):
 for topo in range(3):
  idx=pr*3+topo;cell=Image.new('RGBA',(40,45),(0,0,0,0));d=ImageDraw.Draw(cell)
  if topo==0:
   poly=curve+[(34,38),(3,38)];d.polygon(poly,fill=(62,91,42,255),outline=(233,184,74,255));d.line(curve,fill=(233,184,74,255),width=2)
  else:
   # canto visto do alto: dois perfis se encontram numa diagonal própria
   left=[(20-(x-3)//2,y) for x,y in curve];right=[(20+(x-3)//2,y) for x,y in curve]
   if topo==1:
    poly=left+right[::-1];d.polygon(poly,fill=(62,91,42,255),outline=(233,184,74,255));d.line(left,fill=(233,184,74,255),width=2);d.line(right,fill=(233,184,74,255),width=2)
   else:
    d.line(left,fill=(62,91,42,255),width=6);d.line(right,fill=(62,91,42,255),width=6);d.line(left,fill=(233,184,74,255),width=1);d.line(right,fill=(233,184,74,255),width=1)
  x=(idx%10)*40;y=(idx//10)*45;img.alpha_composite(cell,(x,y))
img.save(OUT);print(OUT)
