# Build validation — v0.2.0-prototype

## Conteúdo jogável

- 4 perfis originais;
- 3 topologias por perfil;
- 12 peças visíveis na única página `Coberturas Vivas`;
- 12 modelos `.smeg` gerados por código próprio;
- 1 modelo legado auxiliar apenas para cladding;
- zero arco/cilindro/capitel/roof model upstream no JAR;
- ícones novos gerados pela ordem da página, sem usar Shape ID como atlas.

## Geometria

- 12 OBJ de referência;
- 6.936 vértices no modelo lógico;
- 13.056 faces no modelo lógico;
- bordas equivalentes;
- determinismo;
- export `.smeg` validado como JSON;
- colisão conservadora por bounds neste protótipo.

## Build

- Java 8u492;
- Gradle 2.14.1;
- ForgeGradle 1.2.2;
- target Forge 1.7.10;
- `clean build sourcesJar`: sucesso;
- runtime: 165 classes, Java major 51;
- ASM BasicVerifier: 1484 OK / 0 BAD;
- namespace antigo ausente;
- metadata UTF-8;
- LICENSE/NOTICE no runtime e sources.

## Checksums

- runtime: `dcb7e55f2a4f9166a30abbe0414254704e94f7e796c3a8579f509fdbc4e59f7a`
- sources: `3218f61f9460c7fe5ca0f85d00012c3dacead266d11d59f4e7c7ba7f473f6833`

## Limites deliberados

- ainda usa o engine MIT para bloco/material/orientação;
- colisão ainda não acompanha perfeitamente cada curva;
- GUI funcional ainda usa o container compacto 1.7.10, não o mockup final;
- malhas têm alta densidade e só devem ser testadas em poucas peças;
- cumeeira, vale, beiral e ponta topológica ainda não estão no JAR;
- runtime real do Pai decide aprovação.
