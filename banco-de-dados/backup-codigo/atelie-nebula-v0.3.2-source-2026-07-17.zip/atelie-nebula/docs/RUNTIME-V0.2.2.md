# Runtime v0.2.2 — primeira geometria aprovada

Feedback do Pai:

> “Ficou ótimo, mas preciso de mais coisa, não só isso.”

## Aprovado

- cliente iniciou;
- aba criativa própria apareceu;
- 12 peças paramétricas renderizaram corretamente;
- correção de winding funcionou;
- material do bloco aparece nas peças;
- primeira família `Coberturas Vivas` provada no runtime.

## Nova exigência

O Ateliê precisa recuperar a amplitude de proposta do ArchitectureCraft —
possibilitar edifícios inteiros — sem copiar sua GUI, catálogo ou formas.

## Direção v0.3

- HUD `Livro de Moldes` 320×240;
- cinco famílias;
- alvo de 52 combinações significativas;
- prévia 3D central;
- seleção família/perfil/topologia;
- novas geometrias para arcos, colunas, painéis e grades;
- nenhum novo JAR até a experiência completa estar desenhada.
