# Sistema paramétrico de formas

## Chave persistente

Cada peça guarda uma chave estável, não um ID de modelo arbitrário:

```text
family/profile/topology/variant
```

Exemplo NBT:

```text
Family: roof
Profile: pagoda_concave
Topology: outer_corner
Variant: ribbed
BaseName: minecraft:stained_hardened_clay
BaseData: 13
Facing: 2
Turn: 1
Mirror: false
```

## Gerador

Perfis são curvas 2D normalizadas em coordenadas 0..16. A topologia transforma
essa curva em malha 3D:

- extrusão para peças retas;
- revolução parcial para colunas;
- interseção de dois perfis para cantos internos;
- união para cantos externos/cumeeiras;
- recorte modular para arcos.

Isso evita manter centenas de arquivos de modelo quase iguais.

## Primeira matriz — cobertura

| Perfil | Reta | C. externo | C. interno | Cumeeira | Vale | Beiral | Ponta |
|---|---:|---:|---:|---:|---:|---:|---:|
| Linear 45° | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | — |
| Suave 33° | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | — |
| Pagoda Côncava | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Ponta Ascendente | ✓ | ✓ | — | — | — | ✓ | ✓ |

São 25 combinações iniciais geradas por quatro perfis, sem copiar a geometria
das Roof Tiles MIT.

## Colisão

A malha visual é independente das caixas de colisão. Cada gerador também produz
uma decomposição conservadora em caixas 1/8 ou 1/16, limitada por orçamento.

## Materiais

O material base é salvo pelo nome de registro e metadata. A peça consulta:

- textura por face;
- cor/tint;
- luz;
- dureza;
- ferramenta de coleta;
- render pass/transparência;
- drop de origem.

Blocos especiais sem modelo cúbico válido recebem rejeição explícita na Mesa de
Moldes, não fallback silencioso.
