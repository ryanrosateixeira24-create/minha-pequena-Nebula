# Hotfix v0.2.1 — pre-init sem janelas legadas

Teste real do Pai em 2026-07-16:

```text
Cannot find resource /assets/nebulaatelier/models/shape/window_frame_side.smeg
```

## Causa

A v0.2.0 removeu corretamente os modelos de janela antigos, mas o construtor do
cliente ainda executava `RenderWindow.init(this)`, que carregava esses recursos
de forma ansiosa mesmo sem qualquer janela visível no catálogo.

## Correção

- removida a inicialização de RenderWindow na v0.2;
- nenhum modelo antigo foi recolocado;
- catálogo continua limitado às 12 coberturas próprias;
- recursos de startup auditados: sawbench + cladding presentes;
- v0.2.0 movida para arquivo-morto, não apagada.

## Validação

- build/reobf: sucesso;
- 165 classes major 51;
- ASM 1484 OK / 0 BAD;
- 12 modelos paramétricos + 1 auxiliar;
- integridade ZIP: OK.

Runtime SHA-256:
`16c07307cbfce5fe76ff16fa85e85dc6b8d4b47f7e5bec627442c8b147ee4a3f`
