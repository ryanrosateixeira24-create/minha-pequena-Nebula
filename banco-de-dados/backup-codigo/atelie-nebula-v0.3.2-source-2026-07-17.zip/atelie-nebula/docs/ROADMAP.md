# Roadmap v0.2

## Fase 0 — rejeição preservada

- [x] v0.1 compilada e tecnicamente válida;
- [x] feedback do Pai aceito;
- [x] JAR/source movidos para arquivo-morto;
- [x] projeto literal preservado em experimental;
- [x] nova visão escrita antes de código.

## Fase A — geometria independente de Minecraft

- [x] representação de perfil 2D em 1/16;
- [x] triangulação/extrusão determinística;
- [x] Linear 45°;
- [x] Suave 33°;
- [x] Pagoda Côncava;
- [x] Ponta Ascendente;
- [x] pranchas isométricas das quatro;
- [x] equivalência de bordas entre peças vizinhas;
- [x] 12 OBJ gerados, 6.936 vértices e 13.056 faces;
- [ ] revisão artística das curvas antes do porte Java.

## Fase B — matriz de telhado

- [x] reta (protótipo Python);
- [x] canto externo (protótipo Python);
- [x] canto interno (protótipo Python);
- [ ] cumeeira;
- [ ] vale;
- [ ] beiral;
- [ ] ponta;
- [ ] colisão conservadora;
- [ ] nenhuma forma copiada do catálogo v0.1.

## Fase C — Forge 1.7.10 mínimo

- [x] engine MIT isolado como infraestrutura temporária;
- [x] material por registry name/metadata;
- [x] 12 modelos paramétricos exportados e carregáveis;
- [x] Compasso de Orientação rebatizado;
- [x] JAR v0.2 compilado/reobfuscado;
- [x] catálogo visível limitado às 12 peças novas;
- [x] teste real do Pai: v0.2.2 abriu e as 12 peças ficaram ótimas;
- [ ] substituir colisão bounds por decomposição das curvas;
- [ ] portar gerador Python para Java e remover modelos pré-exportados.

## Fase D — Mesa de Moldes

- [ ] GUI própria família/perfil/topologia;
- [ ] preview 3D central;
- [ ] consumo por volume;
- [ ] receita e automação sem duplicação.

## Fase E — outras famílias

- [ ] arcos;
- [ ] colunas;
- [ ] painéis;
- [ ] grades;
- [ ] integração na torre aprovada.
