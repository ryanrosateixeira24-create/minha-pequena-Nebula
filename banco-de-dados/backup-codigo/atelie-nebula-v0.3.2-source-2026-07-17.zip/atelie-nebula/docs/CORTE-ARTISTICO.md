# Corte artístico — o que sai e o que nasce

Autoria também é remover.

## Fora do catálogo principal

- Doric/Ionic/Corinthian como famílias centrais;
- triglyph/metope;
- oito frações fixas de esfera;
- LH/RH como peças separadas quando espelhamento resolve;
- arcos diâmetro 3/4 partidos manualmente em A/B/C;
- “smart ridge” como ícone separado;
- dezenas de balustrades quase duplicadas.

Essas capacidades podem existir por parâmetros, mas não ocupam a identidade nem
a navegação principal.

## Novas famílias

### Coberturas Vivas

Linear, suave, pagoda côncava, ponta ascendente e cúpula segmentada, combinadas
com topologias geradas.

### Arcos do Outro Mundo

Redondo, ogival, ferradura, Yemma largo e nuvem dupla, com vão parametrizado.

### Colunas-Lanterna

Circular, octogonal, afunilada, canelada e lanterna; bases/capitéis derivados do
mesmo perfil.

### Painéis e Medalhões

Disco, halo, janela-lanterna, treliça oriental e nuvem.

### Grades de Nuvem

Simples, halo, voluta, escada e transições geradas automaticamente.

## Critério

Uma nova peça só entra se:

1. mudar uma silhueta arquitetônica real;
2. não puder ser obtida por rotação/espelhamento/parâmetro;
3. continuar legível na escala Minecraft;
4. justificar seu lugar na Mesa de Moldes.
