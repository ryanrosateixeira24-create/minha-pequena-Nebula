# Ateliê Nébula v0.3 — proposta completa

## Promessa

Oferecer a liberdade arquitetônica que tornou ArchitectureCraft útil, sem
reproduzir seu catálogo, sua bancada ou sua linguagem visual.

## Catálogo alvo — 52 combinações significativas

### 1. Coberturas Vivas — 25

Quatro perfis atuais + Cúpula Segmentada, combinados conforme compatibilidade:

- reta;
- canto externo;
- canto interno;
- cumeeira;
- vale;
- beiral;
- ponta.

### 2. Arcos do Outro Mundo — 9

- redondo;
- ogival;
- ferradura;
- Yemma largo;
- nuvem dupla;
- vãos 1/3/5/7 tratados por módulos, não A/B/C manuais.

### 3. Colunas-Lanterna — 7

- circular;
- octogonal;
- afunilada;
- canelada;
- lanterna;
- base;
- capitel próprio.

### 4. Painéis e Medalhões — 6

- disco;
- halo;
- janela-lanterna;
- treliça oriental;
- painel de nuvem;
- moldura conectável.

### 5. Grades de Nuvem — 5

- simples;
- halo;
- voluta;
- corrimão inclinado;
- canto/transição automática.

## HUD — Livro de Moldes

Não haverá grade de dezenas de ícones.

- marcadores verticais de família à esquerda;
- prévia 3D central grande;
- perfis como páginas na parte superior;
- topologias à direita;
- material e resultado abaixo da prévia;
- inventário normal na faixa inferior;
- encaixes compatíveis destacados em dourado;
- custo exibido por volume real;
- formas incompatíveis ficam explicadas, não apenas desativadas.

## Ferramentas

- Compasso de Orientação: gira, troca face-base e espelha;
- Cinzel de Perfil: troca perfil compatível no lugar;
- Régua de Encaixe: controla conexão automática;
- Pele de Material: acabamento secundário.

## Regras de qualidade

- nenhuma forma entra sem prancha em três ângulos;
- nenhuma família entra com menos de três usos reais;
- nenhum modelo é mantido só para inflar o catálogo;
- forma visual e colisão são testadas separadamente;
- runtime do Pai aprova cada família antes da próxima.
