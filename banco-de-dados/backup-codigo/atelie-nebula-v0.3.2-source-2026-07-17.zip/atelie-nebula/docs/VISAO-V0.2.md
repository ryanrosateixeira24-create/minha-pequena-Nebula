# Visão v0.2 — capacidades familiares, formas próprias

## Identidade

O Ateliê Nébula é um sistema de modelagem arquitetônica de baixa resolução,
feito para Minecraft 1.7.10 e para a linguagem do Outro Mundo: curvas claras,
silhuetas fortes, ornamento legível e peças que continuam parecendo Minecraft.

Não é ArchitectureCraft com outra cor.

## Fluxo de uso

### Mesa de Moldes

A GUI tem quatro decisões, em vez de uma grade de 83 ícones:

1. **Material** — bloco ou slab de origem;
2. **Família** — cobertura, arco, coluna, painel ou grade;
3. **Perfil** — a personalidade da curva;
4. **Topologia** — reta, canto, encontro, ponta ou terminação.

A prévia 3D ocupa o centro. O resultado fica à direita. A quantidade de material
é calculada pelo volume real da peça.

### Ferramentas

- **Compasso de Orientação:** gira 90°, troca face-base e espelha;
- **Cinzel de Perfil:** percorre perfis compatíveis sem quebrar a peça;
- **Régua de Encaixe:** liga/desliga conexão automática com vizinhos;
- **Pele de Material:** acabamento secundário apenas onde o perfil permite.

## Famílias

### Cobertura

Perfis:

- Linear 45°;
- Suave 33°;
- Pagoda Côncava;
- Ponta Ascendente;
- Cúpula Segmentada.

Topologias:

- faixa reta;
- canto externo;
- canto interno;
- cumeeira;
- vale;
- beiral;
- terminação/ponta.

### Arcos

Perfis:

- redondo;
- ogival;
- ferradura;
- Yemma largo;
- nuvem dupla.

Vãos paramétricos de 1, 3, 5 e 7 blocos, divididos automaticamente em módulos.

### Colunas

- redonda;
- octogonal;
- afunilada;
- canelada;
- lanterna;
- base e capitel próprios.

### Painéis

- medalhão circular;
- janela-lanterna;
- treliça oriental;
- painel de nuvem;
- moldura conectável.

### Grades

- simples;
- halo;
- voluta de nuvem;
- corrimão de escada;
- canto/transição gerados pelo mesmo perfil.

## Linguagem visual

- curvas discretizadas em 1/16 de bloco;
- arestas principais limpas;
- ornamentação grande o bastante para leitura à distância;
- sem capitéis gregos copiados;
- sem catálogo clássico herdado como identidade;
- extensões do Yemma não são uma página extra: são parte do núcleo visual.
