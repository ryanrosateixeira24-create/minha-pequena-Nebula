# Hotfix v0.2.2 — winding e aba criativa

Teste real da v0.2.1:

- Minecraft abriu;
- 12 itens foram produzidos/colocados;
- formatos pareciam cadeiras, paredes e quadrados incompletos;
- itens ficavam perdidos sem aba própria.

## Causa geométrica

Topos tinham normal -Y e fundos +Y. As quatro paredes também apontavam para
dentro. O backface culling descartava justamente as superfícies curvas.

## Correção

- topo: normal +Y;
- fundo: normal -Y;
- paredes: -Z, +Z, -X e +X explícitas;
- 12 OBJ e 12 SMEG regenerados;
- teste automático verifica normal do primeiro triângulo superior;
- aba `Ateliê Nébula` adicionada ao criativo;
- PT-BR `itemGroup.nebulaatelier`;
- v0.2.1 arquivada sem apagar.

## Validação

- geometria: 12 malhas, bordas e determinismo OK;
- SMEG winding top: 12/12 OK;
- build/reobf: sucesso;
- Java major 51;
- ASM: 1487 OK / 0 BAD.

Runtime SHA-256:
`1733bf9478ec7858e8020dbe2d5a6c3bfa48c95b18989d7d534c5cb6b0e61200`
