#!/usr/bin/env python3
from pathlib import Path
import json,re
root=Path(__file__).resolve().parents[1]
java=list((root/'src').rglob('*.java'));assert len(java)==72,len(java)
text='\n'.join(p.read_text(encoding='utf-8') for p in java)
assert 'gcewing.architecture' not in text
shape=(root/'src/mod/com/nebula/atelier/Shape.java').read_text(encoding='utf-8')
entries=re.findall(r'^\s*([A-Za-z][A-Za-z0-9_]*)\((\d+),\s*"([^"]+)"',shape.split('public enum Shape {',1)[1].split('\n;',1)[0],re.M)
ids=[int(e[1]) for e in entries];assert len(ids)==95 and len(set(ids))==95
new=[e for e in entries if 100<=int(e[1])<=111];assert len(new)==12
saw=(root/'src/mod/com/nebula/atelier/SawbenchTE.java').read_text(encoding='utf-8')
visible=re.findall(r'Living(?:Linear|Soft|Pagoda|Upturn)(?:Straight|Outer|Inner)',saw)
assert len(visible)==12 and len(set(visible))==12
assert saw.count('new ShapePage(')==1
models=list((root/'src/resources/assets/nebulaatelier/models/shape').rglob('*.smeg'))
assert len(models)==13,[p.name for p in models]
assert {p.name for p in models if 'v02' in p.parts}=={
 p+'_'+t+'.smeg' for p in ('linear45','soft33','pagoda','upturn') for t in ('straight','outer_corner','inner_corner')}
for p in models:
 data=json.loads(p.read_text(encoding='utf-8'));assert data['bounds'] and data['faces']
meta=json.loads((root/'src/resources/mcmod.info').read_text(encoding='utf-8'))[0]
assert meta['version']=='0.3.2-collision-preview' and meta['modid']=='nebulaatelier'
client=(root/'src/mod/com/nebula/atelier/NebulaAtelierClient.java').read_text(encoding='utf-8')
assert 'RenderWindow.init(this)' not in client
main=(root/'src/mod/com/nebula/atelier/NebulaAtelier.java').read_text(encoding='utf-8')
assert 'new CreativeTabs("nebulaatelier")' in main and 'creativeTab = tabAtelier' in main
assert 'itemGroup.nebulaatelier=' in (root/'src/resources/assets/nebulaatelier/lang/pt_BR.lang').read_text(encoding='utf-8')
gui=(root/'src/mod/com/nebula/atelier/SawbenchGui.java').read_text(encoding='utf-8')
container=(root/'src/mod/com/nebula/atelier/SawbenchContainer.java').read_text(encoding='utf-8')
assert 'gui_gallery_bg.png' in gui and 'drawMoldBook()' in gui
assert 'row * 4 + col' in gui and 'drawShapeIcon(slot' in gui
assert 'guWidth = 320' in container and 'guiHeight = 240' in container
assert 'inputSlotLeft = 27' in container and 'outputSlotLeft = 278' in container
assert (root/'src/resources/assets/nebulaatelier/textures/gui/gui_gallery_bg.png').exists()
assert (root/'LICENSE').exists() and (root/'NOTICE.md').exists()
print('ATELIE_V02_SOURCE=OK java=72 enum=95 visible_shapes=12 generated_models=12 legacy_visible=0 pages=1 license=OK')
