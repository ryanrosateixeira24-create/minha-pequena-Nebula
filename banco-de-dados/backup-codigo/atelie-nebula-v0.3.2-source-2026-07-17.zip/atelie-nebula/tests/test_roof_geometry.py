#!/usr/bin/env python3
from pathlib import Path
import sys,hashlib
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'prototype'))
from roof_geometry import PROFILES,build_mesh,generate_all

meshes=[]
for profile in PROFILES:
 for topology in ('straight','outer_corner','inner_corner'):
  m=build_mesh(profile,topology);m.validate();meshes.append(m)
  assert len(m.vertices)==578
  assert len(m.faces)==1088
  assert min(v[0] for v in m.vertices)>=0 and max(v[0] for v in m.vertices)<=1
  assert min(v[2] for v in m.vertices)>=0 and max(v[2] for v in m.vertices)<=1
# perfis são realmente distintos
signatures={tuple(round(p.height(i/16),5) for i in range(17)) for p in PROFILES}
assert len(signatures)==4
# cantos compartilham exatamente o perfil nas bordas correspondentes
for p in PROFILES:
 outer=build_mesh(p,'outer_corner');inner=build_mesh(p,'inner_corner')
 # top vertices first, grid z*(17)+x
 for i in range(17):
  assert abs(outer.vertices[i][1]-p.height(i/16))<1e-9 # z=0
  assert abs(inner.vertices[i][1]-p.height(0))<1e-9     # min(x,0)
# winding: topo aponta +Y, fundo aponta -Y.
def normal_y(mesh,face):
 a,b,c=(mesh.vertices[i] for i in face[:3])
 ux,uy,uz=(b[i]-a[i] for i in range(3));vx,vy,vz=(c[i]-a[i] for i in range(3))
 return uz*vx-ux*vz
probe=build_mesh(PROFILES[0],'straight')
assert normal_y(probe,probe.faces[0])>0
assert normal_y(probe,probe.faces[2])<0
# determinismo
m1=build_mesh(PROFILES[2],'outer_corner');m2=build_mesh(PROFILES[2],'outer_corner')
assert m1.vertices==m2.vertices and m1.faces==m2.faces
out=root/'concepts/test-meshes';generated=generate_all(out)
assert len(generated)==12 and len(list(out.glob('*.obj')))==12
print('ROOF_GEOMETRY=OK profiles=4 topologies=3 meshes=12 vertices=%d faces=%d seams=OK deterministic=OK'%(
 sum(len(m.vertices) for m in meshes),sum(len(m.faces) for m in meshes)))
