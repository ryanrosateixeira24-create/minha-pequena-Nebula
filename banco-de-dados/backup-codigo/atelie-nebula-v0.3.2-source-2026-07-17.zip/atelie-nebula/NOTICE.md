# NOTICE — reformulação Ateliê Nébula v0.2

ArchitectureCraft, por Greg Ewing, foi estudado como referência funcional e de
engenharia sob licença MIT. A licença original está preservada em
`LICENSE-MIT-ARCHITECTURECRAFT`.

A v0.1 usava diretamente código e modelos MIT; foi rejeitada e arquivada.

A v0.2 não reutilizará o catálogo/modelos `.smeg` como identidade. Seu sistema
de perfis, topologias, GUI, nomes e geometrias será novo. Se partes do engine MIT
forem adaptadas futuramente, o copyright e a licença continuarão acompanhando o
código e o JAR.

Referências:

- https://github.com/gcewing/ArchitectureCraft
- https://www.csse.canterbury.ac.nz/greg.ewing/minecraft/mods/ArchitectureCraft/
