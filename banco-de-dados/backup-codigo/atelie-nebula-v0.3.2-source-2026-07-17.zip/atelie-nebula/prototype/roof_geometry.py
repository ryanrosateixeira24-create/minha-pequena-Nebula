#!/usr/bin/env python3
"""Geometria paramétrica original do Ateliê Nébula v0.2."""
from dataclasses import dataclass
from pathlib import Path
from math import sqrt

@dataclass(frozen=True)
class Profile:
    key:str
    title:str
    samples:tuple
    def height(self,t):
        t=max(0.0,min(1.0,t));p=t*(len(self.samples)-1);i=int(p)
        if i>=len(self.samples)-1:return self.samples[-1]
        f=p-i;return self.samples[i]*(1-f)+self.samples[i+1]*f

PROFILES=(
 Profile('linear45','Linear 45°',tuple(1-i/16 for i in range(17))),
 Profile('soft33','Suave 33°',tuple(0.6875*(1-i/16) for i in range(17))),
 Profile('pagoda','Pagoda Côncava',(1,.86,.73,.61,.51,.43,.36,.30,.25,.21,.17,.14,.11,.08,.055,.025,0)),
 Profile('upturn','Ponta Ascendente',(1,.84,.70,.58,.48,.40,.33,.27,.22,.17,.12,.08,.05,.035,.055,.11,.20)),
)

@dataclass
class Mesh:
    name:str
    vertices:list
    faces:list
    def validate(self):
        assert self.vertices and self.faces
        for v in self.vertices:
            assert len(v)==3 and all(x==x and abs(x)<100 for x in v)
        for f in self.faces:
            assert len(f) in (3,4) and all(0<=i<len(self.vertices) for i in f)
        return self
    def write_obj(self,path):
        with open(path,'w',encoding='utf-8') as out:
            out.write('# Ateliê Nébula parametric prototype — original geometry\n')
            out.write('o %s\n'%self.name)
            for x,y,z in self.vertices:out.write('v %.7f %.7f %.7f\n'%(x,y,z))
            for face in self.faces:out.write('f '+' '.join(str(i+1) for i in face)+'\n')


def height_function(profile,topology):
    if topology=='straight':return lambda x,z:profile.height(x)
    if topology=='outer_corner':return lambda x,z:profile.height(max(x,z))
    if topology=='inner_corner':return lambda x,z:profile.height(min(x,z))
    if topology=='ridge':return lambda x,z:profile.height(abs(2*x-1))
    if topology=='valley':return lambda x,z:max(0.0,profile.height(x)+profile.height(z)-1.0)
    raise ValueError(topology)


def build_mesh(profile,topology,resolution=16,thickness=0.10):
    h=height_function(profile,topology);n=resolution
    vertices=[]
    # top, then underside following surface with minimum thickness and floor clamp
    for layer in (0,1):
        for z in range(n+1):
            for x in range(n+1):
                px=x/n;pz=z/n;top=h(px,pz)
                # Cobertura estrutural sólida: superfície paramétrica sobre base plana.
                py=top if layer==0 else 0.0
                vertices.append((px,py,pz))
    stride=(n+1)*(n+1);faces=[]
    def vi(layer,x,z):return layer*stride+z*(n+1)+x
    for z in range(n):
        for x in range(n):
            # Topo: winding anti-horário visto de cima, normal +Y.
            a,b,c,d=vi(0,x,z),vi(0,x+1,z),vi(0,x+1,z+1),vi(0,x,z+1)
            faces.extend(((a,c,b),(a,d,c)))
            # Fundo: ordem inversa, normal -Y.
            a,b,c,d=vi(1,x,z),vi(1,x,z+1),vi(1,x+1,z+1),vi(1,x+1,z)
            faces.extend(((a,c,b),(a,d,c)))
    # Paredes com winding exterior explícito: -Z, +Z, -X, +X.
    for i in range(n):
        faces.append((vi(0,i,0),vi(0,i+1,0),vi(1,i+1,0),vi(1,i,0)))
        faces.append((vi(0,i+1,n),vi(0,i,n),vi(1,i,n),vi(1,i+1,n)))
        faces.append((vi(0,0,i+1),vi(0,0,i),vi(1,0,i),vi(1,0,i+1)))
        faces.append((vi(0,n,i),vi(0,n,i+1),vi(1,n,i+1),vi(1,n,i)))
    return Mesh('%s_%s'%(profile.key,topology),vertices,faces).validate()


def generate_all(output):
    output=Path(output);output.mkdir(parents=True,exist_ok=True);result=[]
    for profile in PROFILES:
        for topology in ('straight','outer_corner','inner_corner'):
            mesh=build_mesh(profile,topology);mesh.write_obj(output/(mesh.name+'.obj'));result.append(mesh)
    return result

if __name__=='__main__':
    root=Path(__file__).resolve().parents[1]
    meshes=generate_all(root/'concepts/meshes')
    print('generated',len(meshes),'meshes',sum(len(m.vertices) for m in meshes),'vertices',sum(len(m.faces) for m in meshes),'faces')
