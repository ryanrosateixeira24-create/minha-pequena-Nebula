#!/usr/bin/env python3
from pathlib import Path
from math import sqrt
from PIL import Image,ImageDraw,ImageFont
from roof_geometry import PROFILES,build_mesh

BG=(238,226,235);CARD=(248,245,234);INK=(42,31,92);NAVY=(21,34,62);GOLD=(233,184,74);GREEN=(62,91,42)

def normal(a,b,c):
 ux,uy,uz=(b[i]-a[i] for i in range(3));vx,vy,vz=(c[i]-a[i] for i in range(3))
 nx,ny,nz=uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx
 l=sqrt(nx*nx+ny*ny+nz*nz) or 1
 return nx/l,ny/l,nz/l

def render(mesh,w=430,h=260):
 scale=175;pts=[]
 def project(v):
  x,y,z=v;return ((x-z)*scale,(x+z)*scale*.42-y*scale)
 faces=[];light=(-.35,.85,-.4)
 for f in mesh.faces:
  if len(f)!=3:continue
  vs=[mesh.vertices[i] for i in f];n=normal(*vs)
  if n[1]<.05:continue
  shade=max(.35,min(1.0,n[0]*light[0]+n[1]*light[1]+n[2]*light[2]))
  color=tuple(int(GREEN[i]*(.65+.45*shade)) for i in range(3))
  poly=[project(v) for v in vs];depth=sum(sum(v) for v in vs)/3
  faces.append((depth,poly,color))
 allp=[p for _,poly,_ in faces for p in poly];minx=min(x for x,y in allp);maxx=max(x for x,y in allp);miny=min(y for x,y in allp);maxy=max(y for x,y in allp)
 im=Image.new('RGBA',(w,h),(0,0,0,0));d=ImageDraw.Draw(im);ox=(w-(maxx-minx))/2-minx;oy=(h-(maxy-miny))/2-miny+15
 for _,poly,color in sorted(faces,key=lambda x:x[0]):
  q=[(x+ox,y+oy) for x,y in poly];d.polygon(q,fill=color,outline=NAVY)
 # linha dourada da silhueta superior
 return im

def main():
 root=Path(__file__).resolve().parents[1]
 topologies=[('straight','RETA'),('outer_corner','CANTO EXTERNO'),('inner_corner','CANTO INTERNO')]
 W,H=1580,1370;out=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(out)
 try:ft=ImageFont.truetype('DejaVuSans-Bold.ttf',28);fh=ImageFont.truetype('DejaVuSans-Bold.ttf',18);fb=ImageFont.truetype('DejaVuSans.ttf',15)
 except:ft=fh=fb=ImageFont.load_default()
 d.text((W//2,18),'12 MALHAS ORIGINAIS — PERFIL × TOPOLOGIA',anchor='ma',font=ft,fill=INK)
 for col,(_,title) in enumerate(topologies):d.text((350+col*480,68),title,anchor='ma',font=fh,fill=INK)
 totalv=totalf=0
 for row,profile in enumerate(PROFILES):
  label=profile.title.replace(' ','\n')
  d.multiline_text((60,200+row*300),label,anchor='mm',align='center',font=fb,fill=INK,spacing=3)
  for col,(topology,_) in enumerate(topologies):
   mesh=build_mesh(profile,topology);totalv+=len(mesh.vertices);totalf+=len(mesh.faces)
   x=125+col*480;y=105+row*300
   d.rounded_rectangle((x,y,x+450,y+270),radius=10,fill=CARD,outline=NAVY,width=2)
   pic=render(mesh);out.paste(pic,(x+10,y+5),pic)
   d.text((x+225,y+242),'%d vértices • %d faces'%(len(mesh.vertices),len(mesh.faces)),anchor='ma',font=fb,fill=(75,57,73))
 d.text((W//2,1325),'geradas por código: %d vértices • %d faces • zero .smeg copiado'%(totalv,totalf),anchor='ma',font=fh,fill=INK)
 p=root/'concepts/03-matriz-parametrica-renderizada.png';out.save(p);print(p)

if __name__=='__main__':main()
