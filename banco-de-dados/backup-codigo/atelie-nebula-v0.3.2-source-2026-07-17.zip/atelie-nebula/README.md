# Ateliê Nébula — reformulação v0.2

Mod arquitetônico próprio para Minecraft Forge 1.7.10.

## O que aconteceu com a v0.1

A primeira alpha era um fork MIT rebatizado e recolorido de ArchitectureCraft.
Embora legal e tecnicamente funcional, o Pai a rejeitou corretamente como uma
cópia barata: até as formas eram as mesmas. Ela foi movida integralmente para
`mod/experimental/nebula-atelier-v0.1-fork-literal-reprovado/`.

## Nova regra

Preservar **capacidades**, não copiar catálogo:

- transformar materiais em peças;
- orientar e girar;
- combinar telhados e cantos;
- construir arcos, colunas, janelas e grades;
- herdar textura/luz/dureza/drop.

Mas geometria, catálogo, nomes, GUI e fluxo de seleção serão próprios.

## Ideia central

O Ateliê não apresenta 83 modelos fixos. Ele combina:

**família + perfil + topologia + acabamento**

Exemplo:

```text
Cobertura + Pagoda Côncava + Canto Externo + Nervura Clara
```

Uma família paramétrica gera muitas peças coerentes sem uma parede de ícones
quase iguais.

## Estado

**Fase de desenho v0.2. Sem JAR.**

O próximo código será apenas o gerador geométrico de coberturas, validado em
pranchas antes de voltar ao Forge.
